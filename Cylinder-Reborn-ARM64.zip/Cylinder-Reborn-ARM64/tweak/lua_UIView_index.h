#import "../lua/lua.h"

int l_uiview_index(lua_State *L);
void l_create_viewindextable(lua_State *L);
