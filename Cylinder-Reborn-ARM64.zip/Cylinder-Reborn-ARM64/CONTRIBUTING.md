# Pull request policy

Feel free to post custom Lua scripts to [/r/cylinder](http://reddit.com/r/cylinder). 
Once this is on Packix there will also be an easy way for you to submit your scripts there too.
