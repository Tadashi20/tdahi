#import <UIKit/UIKit.h>

@interface CLAlignedTableViewCell : UITableViewCell
@property (nonatomic, retain) UILabel *numberLabel;
@end
