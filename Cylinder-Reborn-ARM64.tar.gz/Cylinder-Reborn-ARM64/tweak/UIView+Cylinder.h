#import <UIKit/UIKit.h>

@interface UIView(Cylinder)
@property (nonatomic, assign) BOOL wasModifiedByCylinder;
@end
